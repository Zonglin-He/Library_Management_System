import dao.BookDAO;
import dao.BorrowDAO;
import model.Book;

import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BookDAO bookDAO = new BookDAO();
        BorrowDAO borrowDAO = new BorrowDAO();

        while (true) {
            System.out.println("\n=== Library Management System ===");
            System.out.println("1. Add Book");
            System.out.println("2. View All Books");
            System.out.println("3. Delete Book");
            System.out.println("4. Borrow Book");
            System.out.println("5. Return Book");
            System.out.println("6. Check Borrowing Records");
            System.out.println("7. Exit");

            System.out.print("Please enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            if (choice == 1) {
                System.out.print("Book name: ");
                String title = scanner.nextLine();
                System.out.print("Author: ");
                String author = scanner.nextLine();

                Book book = new Book();
                book.setTitle(title);
                book.setAuthor(author);
                bookDAO.addBook(book);

            } else if (choice == 2) {
                List<Book> list = bookDAO.getAllBooks();
                System.out.println("--- All Books ---");
                for (Book b : list) {
                    System.out.println("ID: " + b.getId() +
                            ", BOOK NAME: " + b.getTitle() +
                            ", AUTHOR: " + b.getAuthor() +
                            ", BORROWED: " + (b.isBorrowed() ? "Yes" : "No"));
                }
            } else if (choice == 3) {
                System.out.print("Please enter book ID: ");
                int id = scanner.nextInt();
                scanner.nextLine();
                bookDAO.deleteBookById(id);
            }
            else if (choice == 4) {
                System.out.print("Enter the books ID you want to borrow: ");
                int bookId = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Enter the borrower's name: ");
                String userName = scanner.nextLine();
                borrowDAO.borrowBook(bookId, userName);

            } else if (choice == 5) {
                System.out.print("Enter the book ID to be returned: ");
                int bookId = scanner.nextInt();
                borrowDAO.returnBook(bookId);

            }
            else if (choice == 6) {
                borrowDAO.showAllBorrowRecords();
            }
            else {
                break;
            }
        }
    }
}
