package dao;

import util.DBUtil;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;

public class BorrowDAO {
    // 借书：插入借书记录，更新图书为已借出
    public boolean borrowBook(int bookId, String userName) {
        String checkSql = "SELECT is_borrowed FROM books WHERE id = ?";
        String insertSql = "INSERT INTO borrow_records (book_id, user_name, borrow_date) VALUES (?, ?, ?)";
        String updateSql = "UPDATE books SET is_borrowed = true WHERE id = ?";

        try (Connection conn = DBUtil.getConnection()) {
            if (userName == null || userName.trim().isEmpty()) {
                System.out.println("User name cannot be empty.");
                return false;
            }

            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setInt(1, bookId);
            ResultSet rs = checkStmt.executeQuery();

            if (!rs.next()) {
                System.out.println("Book ID does not exist. Cannot borrow.");
                return false;
            }

            if (rs.getBoolean("is_borrowed")) {
                System.out.println("This book is already borrowed.");
                return false;
            }

            PreparedStatement stmt1 = conn.prepareStatement(insertSql);
            stmt1.setInt(1, bookId);
            stmt1.setString(2, userName);
            stmt1.setDate(3, Date.valueOf(LocalDate.now()));
            stmt1.executeUpdate();

            PreparedStatement stmt2 = conn.prepareStatement(updateSql);
            stmt2.setInt(1, bookId);
            stmt2.executeUpdate();

            System.out.println("Borrowing the book successfully!");
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // 还书：更新记录和图书状态
    public void returnBook(int bookId) {
        String checkSql = "SELECT * FROM borrow_records WHERE book_id = ? AND return_date IS NULL";

        try (Connection conn = DBUtil.getConnection()) {
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setInt(1, bookId);
            ResultSet rs = checkStmt.executeQuery();

            if (!rs.next()) {
                System.out.println("There is no outstanding borrowing record for this book at present, " +
                        "so it cannot be returned.");
                return;
            }

            // 有未还记录，才执行归还操作
            String updateRecordSql = "UPDATE borrow_records SET return_date = ? WHERE book_id = ? AND return_date IS NULL";
            String updateBookSql = "UPDATE books SET is_borrowed = false WHERE id = ?";

            PreparedStatement stmt1 = conn.prepareStatement(updateRecordSql);
            stmt1.setDate(1, Date.valueOf(LocalDate.now()));
            stmt1.setInt(2, bookId);
            stmt1.executeUpdate();

            PreparedStatement stmt2 = conn.prepareStatement(updateBookSql);
            stmt2.setInt(1, bookId);
            stmt2.executeUpdate();

            System.out.println("The book was returned successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void showAllBorrowRecords() {
        String sql = "SELECT * FROM borrow_records";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            System.out.println("--- Borrowing Record List ---");
            while (rs.next()) {
                int id = rs.getInt("id");
                int bookId = rs.getInt("book_id");
                String userName = rs.getString("user_name");
                Date borrowDate = rs.getDate("borrow_date");
                Date returnDate = rs.getDate("return_date");

                System.out.println("Record borrower ID: " + id +
                        ", Book ID: " + bookId +
                        ", Borrower: " + userName +
                        ", Borrowing date: " + borrowDate +
                        ", Return or not: " + (returnDate == null ? "No" : "Yes(" + returnDate + ")"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
