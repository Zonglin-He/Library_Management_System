package gui;

import dao.BookDAO;
import dao.BorrowDAO;

import javax.swing.*;

public class LibraryGUI {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Library Management System");
        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        JButton addBookBtn = new JButton("Add Book");
        JButton viewBooksBtn = new JButton("View All Books");
        JButton deleteBookBtn = new JButton("Delete Book");
        JButton borrowBookBtn = new JButton("Borrow Book");
        JButton returnBookBtn = new JButton("Return Book");
        JButton viewRecordsBtn = new JButton("Check Borrowing Records");

        addBookBtn.setBounds(50, 30, 300, 30);
        viewBooksBtn.setBounds(50, 70, 300, 30);
        deleteBookBtn.setBounds(50, 110, 300, 30);
        borrowBookBtn.setBounds(50, 150, 300, 30);
        returnBookBtn.setBounds(50, 190, 300, 30);
        viewRecordsBtn.setBounds(50, 230, 300, 30);

        frame.add(addBookBtn);
        frame.add(viewBooksBtn);
        frame.add(deleteBookBtn);
        frame.add(borrowBookBtn);
        frame.add(returnBookBtn);
        frame.add(viewRecordsBtn);

        BookDAO bookDAO = new BookDAO();
        BorrowDAO borrowDAO = new BorrowDAO();

        addBookBtn.addActionListener(e -> new AddBookDialog(frame, bookDAO));
        viewBooksBtn.addActionListener(e -> new ViewBooksDialog(frame, bookDAO));
        deleteBookBtn.addActionListener(e -> new DeleteBookDialog(frame, bookDAO));
        borrowBookBtn.addActionListener(e -> new BorrowBookDialog(frame, borrowDAO));
        returnBookBtn.addActionListener(e -> new ReturnBookDialog(frame, borrowDAO));
        viewRecordsBtn.addActionListener(e -> new BorrowRecordDialog(frame, borrowDAO));

        frame.setVisible(true);
    }
}


