package gui;

import dao.BookDAO;
import model.Book;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;

public class ViewBooksDialog extends JDialog {
    public ViewBooksDialog(JFrame parent, BookDAO bookDAO) {
        super(parent, "All Books", true);
        setSize(500, 300);
        setLayout(null);

        List<Book> books = bookDAO.getAllBooks();

        String[] columnNames = {"ID", "Title", "Author", "Borrowed"};
        String[][] data = new String[books.size()][4];

        for (int i = 0; i < books.size(); i++) {
            Book b = books.get(i);
            data[i][0] = String.valueOf(b.getId());
            data[i][1] = b.getTitle();
            data[i][2] = b.getAuthor();
            data[i][3] = b.isBorrowed() ? "Yes" : "No";
        }

        JTable table = new JTable(new DefaultTableModel(data, columnNames));
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 20, 440, 220);
        add(scrollPane);

        setLocationRelativeTo(parent);
        setVisible(true);
    }
}

