package gui;

import dao.BorrowDAO;

import javax.swing.*;

public class BorrowBookDialog extends JDialog {
    public BorrowBookDialog(JFrame parent, BorrowDAO borrowDAO) {
        super(parent, "Borrow Book", true);
        setSize(300, 200);
        setLayout(null);

        JLabel idLabel = new JLabel("Book ID:");
        idLabel.setBounds(20, 20, 80, 25);
        add(idLabel);

        JTextField idField = new JTextField();
        idField.setBounds(100, 20, 160, 25);
        add(idField);

        JLabel userLabel = new JLabel("User Name:");
        userLabel.setBounds(20, 60, 80, 25);
        add(userLabel);

        JTextField userField = new JTextField();
        userField.setBounds(100, 60, 160, 25);
        add(userField);

        JButton borrowButton = new JButton("Borrow");
        borrowButton.setBounds(100, 100, 100, 30);
        add(borrowButton);

        borrowButton.addActionListener(e -> {
            try {
                int bookId = Integer.parseInt(idField.getText());
                String userName = userField.getText();
                boolean success = borrowDAO.borrowBook(bookId, userName);
                if (success) {
                    JOptionPane.showMessageDialog(this, "Borrowed successfully!");
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to borrow book." +
                            " Please check your input or book status.");
                }

                dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid input.");
            }
        });

        setLocationRelativeTo(parent);
        setVisible(true);
    }
}

