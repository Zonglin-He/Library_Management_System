package gui;

import dao.BorrowDAO;

import javax.swing.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class BorrowRecordDialog extends JDialog {
    public BorrowRecordDialog(JFrame parent, BorrowDAO borrowDAO) {
        super(parent, "Borrow Records", true);
        setSize(500, 300);
        setLayout(null);

        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setBounds(20, 20, 440, 220);
        add(scrollPane);

        // Capture System.out and redirect
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(out);
        PrintStream old = System.out;
        System.setOut(printStream);
        borrowDAO.showAllBorrowRecords();
        System.out.flush();
        System.setOut(old);

        textArea.setText(out.toString());

        setLocationRelativeTo(parent);
        setVisible(true);
    }
}

