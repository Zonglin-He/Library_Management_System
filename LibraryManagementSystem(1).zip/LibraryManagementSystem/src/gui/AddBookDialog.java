package gui;

import dao.BookDAO;
import model.Book;

import javax.swing.*;

public class AddBookDialog extends JDialog {
    public AddBookDialog(JFrame parent, BookDAO bookDAO) {
        super(parent, "Add Book", true);
        setSize(300, 200);
        setLayout(null);

        JLabel titleLabel = new JLabel("Title:");
        titleLabel.setBounds(20, 20, 80, 25);
        add(titleLabel);

        JTextField titleField = new JTextField();
        titleField.setBounds(100, 20, 160, 25);
        add(titleField);

        JLabel authorLabel = new JLabel("Author:");
        authorLabel.setBounds(20, 60, 80, 25);
        add(authorLabel);

        JTextField authorField = new JTextField();
        authorField.setBounds(100, 60, 160, 25);
        add(authorField);

        JButton addButton = new JButton("Add");
        addButton.setBounds(100, 100, 100, 30);
        add(addButton);

        addButton.addActionListener(e -> {
            String title = titleField.getText();
            String author = authorField.getText();
            if (!title.isEmpty() && !author.isEmpty()) {
                Book book = new Book();
                book.setTitle(title);
                book.setAuthor(author);
                bookDAO.addBook(book);
                JOptionPane.showMessageDialog(this, "Book added!");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Please enter all fields.");
            }
        });

        setLocationRelativeTo(parent);
        setVisible(true);
    }
}

