package gui;

import dao.BookDAO;

import javax.swing.*;

public class DeleteBookDialog extends JDialog {
    public DeleteBookDialog(JFrame parent, BookDAO bookDAO) {
        super(parent, "Delete Book", true);
        setSize(300, 150);
        setLayout(null);

        JLabel idLabel = new JLabel("Book ID:");
        idLabel.setBounds(30, 30, 80, 25);
        add(idLabel);

        JTextField idField = new JTextField();
        idField.setBounds(100, 30, 130, 25);
        add(idField);

        JButton deleteButton = new JButton("Delete");
        deleteButton.setBounds(100, 70, 100, 30);
        add(deleteButton);

        deleteButton.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText());
                bookDAO.deleteBookById(id);
                JOptionPane.showMessageDialog(this, "Book deleted.");
                dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid ID.");
            }
        });

        setLocationRelativeTo(parent);
        setVisible(true);
    }
}

