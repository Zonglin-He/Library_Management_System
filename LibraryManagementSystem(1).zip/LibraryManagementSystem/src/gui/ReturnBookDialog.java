package gui;

import dao.BorrowDAO;

import javax.swing.*;

public class ReturnBookDialog extends JDialog {
    public ReturnBookDialog(JFrame parent, BorrowDAO borrowDAO) {
        super(parent, "Return Book", true);
        setSize(300, 150);
        setLayout(null);

        JLabel idLabel = new JLabel("Book ID:");
        idLabel.setBounds(30, 30, 80, 25);
        add(idLabel);

        JTextField idField = new JTextField();
        idField.setBounds(100, 30, 130, 25);
        add(idField);

        JButton returnButton = new JButton("Return");
        returnButton.setBounds(100, 70, 100, 30);
        add(returnButton);

        returnButton.addActionListener(e -> {
            try {
                int bookId = Integer.parseInt(idField.getText());
                borrowDAO.returnBook(bookId);
                JOptionPane.showMessageDialog(this, "Book returned.");
                dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid ID.");
            }
        });

        setLocationRelativeTo(parent);
        setVisible(true);
    }
}

